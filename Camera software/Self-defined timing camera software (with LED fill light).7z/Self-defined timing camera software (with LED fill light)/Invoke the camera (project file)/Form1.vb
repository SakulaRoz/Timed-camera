﻿Imports System.Drawing.Imaging
Imports System.IO
Imports AForge.Video.DirectShow
Public Class Form1
    Dim videoDevices As FilterInfoCollection
    Dim videoSource As VideoCaptureDevice
    Dim selectedDeviceIndex As Integer = 0
    Dim t As Integer = 0
    Dim savepath As String = System.Environment.CurrentDirectory

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        videoDevices = New FilterInfoCollection(FilterCategory.VideoInputDevice)
        selectedDeviceIndex = 0
        videoSource = New VideoCaptureDevice(videoDevices(selectedDeviceIndex).MonikerString)
        videoSource.VideoResolution = videoSource.VideoCapabilities(selectedDeviceIndex)
        VideoSourcePlayer1.VideoSource = videoSource

        'Open the serial port
        If SerialPort1.IsOpen Then
            SerialPort1.Close()
        End If

        Try
            With SerialPort1
                .PortName = "COM5"
                .BaudRate = 9600

                .Parity = IO.Ports.Parity.None 'Parity check
                .DataBits = 8 'Data bit
                .StopBits = IO.Ports.StopBits.One 'Stop bit
            End With
            'Open
            SerialPort1.Open()

            Label5.Text = "Connected"
            'Button1.Enabled = False
            Button2.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Text = "Fill light"
        SerialPort1.Write("1")
        VideoSourcePlayer1.Start()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Me.Text = "Fill light"
        ' SerialPort1.Write("1")
        ' Timer4.Enabled = True
        paizhao()
        ' Timer3.Enabled = True
    End Sub
    Sub paizhao()
        If videoSource Is Nothing Then
            Return
        End If
        Dim file As String = DateTime.Now.ToString("yyyy-MM-dd hh_mm_ss.JPG")
        Dim bitmap1 As Bitmap = VideoSourcePlayer1.GetCurrentVideoFrame()
        If bitmap1 Is Nothing Then
            Return
        End If
        Dim bitmap2 As Bitmap = New Bitmap(bitmap1, 800, 600)
        'bitmap2.Save(savepath & "\" & file, ImageFormat.Jpeg)
        bitmap2.Save(Path.Combine(savepath, file), ImageFormat.Jpeg)
        bitmap1.Dispose()
        bitmap2.Dispose()
    End Sub

    Sub zidongpai()
        VideoSourcePlayer1.Start()
        Timer2.Enabled = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        't = t + 1
        'If t = Convert.ToInt32(TextBox1.Text) * 60 Then
        '    t = 0
        '    Dim t0 As DateTime = DateTime.Now
        '    Dim t1 As DateTime = DateTime.Parse(t0.ToString("yyyy-MM-dd") & " " & TextBox2.Text)
        '    Dim t2 As DateTime = DateTime.Parse(t0.ToString("yyyy-MM-dd") & " " & TextBox3.Text)
        '    Dim t3 As TimeSpan = t0 - t1
        '    Dim t4 As TimeSpan = t0 - t2
        '    If t3.TotalSeconds > 0 And t4.TotalSeconds < 0 Then
        '        zidongpai()
        '    End If
        'End If
        'Me.GroupBox1.Text = "自动拍照：" & (Convert.ToInt32(TextBox1.Text) * 60 - t) & "s"

        t = t + 1
        Dim SurplusTime As Integer
        SurplusTime = Convert.ToInt32(TextBox1.Text) * 60 - t
        If SurplusTime <= 3 Then

            Dim t0 As DateTime = DateTime.Now
            Dim t1 As DateTime = DateTime.Parse(t0.ToString("yyyy-MM-dd") & " " & TextBox2.Text)
            Dim t2 As DateTime = DateTime.Parse(t0.ToString("yyyy-MM-dd") & " " & TextBox3.Text)
            Dim t3 As TimeSpan = t0 - t1
            Dim t4 As TimeSpan = t0 - t2
            If t3.TotalSeconds > 0 And t4.TotalSeconds < 0 Then
                If SurplusTime = 0 Then
                    t = 0
                    zidongpai()
                ElseIf SurplusTime = 3 Then
                    Me.Text = "Fill light"
                    SerialPort1.Write("1")
                    Timer3.Enabled = True
                End If
            End If
        End If
        Me.GroupBox1.Text = "Automatically take photos：" & SurplusTime & "s"

    End Sub
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)
        t = 0
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        VideoSourcePlayer1.SignalToStop()
        VideoSourcePlayer1.WaitForStop()
        Me.Text = "Fill light off"
        SerialPort1.Write("0")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'If Button4.Text = "Start" Then
        '    Button4.Text = "Termination"
        '    Timer1.Enabled = True
        '    t = 0
        'Else
        '    Button4.Text = "Start"
        '    Timer1.Enabled = False
        '    t = 0
        'End If
        If Timer1.Enabled Then
            Button4.Text = "Start"
            Timer1.Enabled = False
            t = 0
        Else
            Button4.Text = "Termination"
            Timer1.Enabled = True
            t = 0
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If videoSource Is Nothing Then

        Else
            Dim file As String = DateTime.Now.ToString("yyyy-MM-dd hh_mm_ss.JPG")
            Dim bitmap1 As Bitmap = VideoSourcePlayer1.GetCurrentVideoFrame()
            If bitmap1 Is Nothing Then
                Return
            End If
            Dim bitmap2 As Bitmap = New Bitmap(bitmap1, 800, 600)
            bitmap2.Save(savepath & "\" & file, ImageFormat.Jpeg)
            bitmap1.Dispose()
            bitmap2.Dispose()
            VideoSourcePlayer1.SignalToStop()
            VideoSourcePlayer1.WaitForStop()
            Timer2.Enabled = False
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim s As String = InputBox("Please enter the image save path，for example D:\img", "Hint", savepath)
        If s <> "" Then
            If System.IO.Directory.Exists(s) Then
                savepath = s
            Else
                MsgBox("The image save path does not exist, please re-enter")
            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        t = 0
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Me.Text = "Fill light off"
        SerialPort1.Write("0")
        Timer3.Enabled = False
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If SerialPort1.IsOpen Then
            SerialPort1.Close()
        End If
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        Timer4.Enabled = False
    End Sub
End Class
