#include "reg51.h"
#define uchar unsigned char
			 
uchar recdat = 0;	  			   
sbit led1 = P1^0;

void initscon()
{
	SCON = 0x50;
	TMOD = 0x20;
	TH1 =256-3;
	TL1 =256-3;																					 
	ES = 1;
	EA = 1;
	TR1 = 1;
}
 
void main()
{
	initscon();
	while(1);
}

void scon_isr() interrupt 4
{			  
	recdat = SBUF;		 
	if(recdat == '1')
	  led1 = 0;
	if(recdat == '0')
	  led1 = 1;	
				 
	RI = 0;
}